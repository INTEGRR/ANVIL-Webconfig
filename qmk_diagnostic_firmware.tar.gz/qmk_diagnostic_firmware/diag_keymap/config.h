#pragma once

#define RAW_USAGE_PAGE 0xFF60
#define RAW_USAGE_ID 0x61
#define RAW_EPSIZE 32

#define USB_POLLING_INTERVAL_MS 1

#define DEBOUNCE 5

#define FORCE_NKRO
